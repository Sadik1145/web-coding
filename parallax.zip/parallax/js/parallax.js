(function($){

	$.fn.parallax = function(){
		
		var section = $(this);
		var img = section.data("image");  
		section.css({
			"backgroundImage" : `url(${img})`,
			"backgroundRepeat" : "no-repeat",
			"backgroundSize" : "cover",
			"backgroundPosition" : "center -100px",
			"backgroundAttachment" : "fixed",
			"transition" : "0.3s",
		});
		var offset = section.offset().top;
		var totalOffset = offset + section.height();  
		var mainOffset = offset - $(window).height(); 

		$(window).scroll(function(){
			var wScroll = $(this).scrollTop(); 
			if(wScroll > mainOffset && wScroll < totalOffset){
				var x = wScroll - mainOffset; 
			} 
			var speed = x*0.1;
			var bgSpeed = -120 + speed; 
			section.css({
				'backgroundPosition' : 'center ' + bgSpeed + 'px',
			}); 
		});

	}

})(jQuery)